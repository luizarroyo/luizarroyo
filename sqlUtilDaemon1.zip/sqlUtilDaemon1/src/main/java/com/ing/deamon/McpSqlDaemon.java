	package com.ing.deamon;

import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ing.connection.JpaUtil;
import com.ing.connection.McpSqlParameter;
import com.ing.connection.TimeoutControl;
import com.ing.sql.model.Environment;
import com.ing.sql.model.Hostname;
import com.ing.sql.model.OfflineQuery;
import com.ing.sql.model.Parameter;
import com.ing.sql.repository.Environments;
import com.ing.sql.repository.Hostnames;
import com.ing.sql.repository.OfflineQueries;
import com.ing.sql.repository.Parameters;
import com.ing.sql.util.ColumnModel;
import com.ing.sql.util.MessageType;
import com.ing.sql.util.ModuleType;
import com.ing.sql.util.WriteLog;
import com.unisys.mcpsql.provider.DMConnectParams;
import com.unisys.mcpsql.provider.DMConnection;
import com.unisys.mcpsql.provider.DMItemDescription;
import com.unisys.mcpsql.provider.DMLocator;
import com.unisys.mcpsql.provider.DMProviderException;
import com.unisys.mcpsql.provider.DMResultSet;
import com.unisys.mcpsql.provider.DMStatement;
import com.unisys.mcpsql.server.serverimpl.MCPSQLColLob;

import sun.security.util.PendingException;

public class McpSqlDaemon {
	
	@Inject
	private OfflineQueries offlineQueries;
	
	@Inject
	private Parameters Parameters;

	@Inject
	private WriteLog log;

	@Inject
	private OfflineQuery offlineQuery;
	private static List<OfflineQuery> listPendingQueries;
	
	String userId;
	String database;
	
	boolean debug=false;
	
	static String environment;

	ExecutorService executor;
	static List<RunningQuery> exec = new ArrayList<RunningQuery>();
	private static int maxRun = 1;
	
	EntityManager manager;
	
	DMSIIConnections dmsiiConn = new DMSIIConnections();
	
	String version="1.10";
	/*
	 * 1.9 Add numRows after a successful write 
	 * 1.7 Connection Timeout and update pending offline queries to S for user/database 
	 * 1.3 queries allowed only if exec.size() < maxRun
	 *     abort query keep userid
	 *     
	 */

    public static void main( String[] args )     {
    	if ( args.length == 0 ) {
    		System.out.println("Parameter error: environment required");
    		System.out.println("    try <environment> [<parallel runs>]");
    	} else if ( args.length > 1 ) {
    		int newMaxRun=maxRun;
    		try {
    			newMaxRun=Integer.valueOf(args[1]);
    		} catch (Exception e) {
    			
    		}
        	maxRun=newMaxRun;
    		
    	}
    	environment=args[0];
        new McpSqlDaemon().process();
    }
    
    static void log (String msg) {
    	System.out.println( (new SimpleDateFormat("dd-MM-yyyy hh:mm:ss")).format(Calendar.getInstance().getTime())+": "+ msg );
    }
    static void logErr (String msg) {
    	System.err.println( (new SimpleDateFormat("dd-MM-yyyy hh:mm:ss")).format(Calendar.getInstance().getTime())+": "+ msg );
    }
    
    void process()  {

        log( "************************************" );
        log( "*                                  *" );
        log( "*       McpSqlDaemon started       *" );
        log( "*          Version "+version+"            *" );
        log( "*                                  *" );
        log( "************************************" );
        log( "" );

        log( "Environment selected="+environment );
        log( "Maximum number of simultaneos runs="+maxRun );

        manager = JpaUtil.getEntityManager();
    	offlineQueries = new OfflineQueries(manager);
    	
    	Map<String,Object> props=manager.getProperties();
    	
    	executor = Executors.newFixedThreadPool(maxRun);
    	
        TimeoutControl timeoutControl=new TimeoutControl(DMSIIConnections.connections);
        timeoutControl.start();
    	    	
    	try {

       	log=new WriteLog(manager);
    	clearRunningQueries();
    	
    	CheckQueries cq = new CheckQueries(exec);
    	cq.start();
       	
    	while ( true ) {
    		
    		selectPendingQueries();
    		
    		Thread.sleep(20000);
    	}
    	
    	} catch (Exception e) {
    		
    		log("Error in McpSqlDaemon:"+e);
      	    log.writeLogTable("Error in McpSqlDaemon: "+e,
      	    			MessageType.ERROR, ModuleType.OFFLINEQUERY);
    		
    	} finally {
    		manager.close();
    	}
    	
    }
    
    void clearRunningQueries() {
    	
		Session session = manager.unwrap(Session.class);
		Transaction t=session.beginTransaction();
    	List<OfflineQuery> listRunningQueries=offlineQueries.allRunning(null);
    	for (OfflineQuery offQry: listRunningQueries) {
    	    offQry.setMessage("Query aborted by deamon: clearRunningQueries() method");	
    	    offQry.setStatus("C");
    	    offlineQueries.update(offQry);
      	    log.writeLogTable("Offline Query id "
    				+ offQry.getId() 
    				+": Query aborted by deamon: clearRunningQueries() method", MessageType.ERROR, ModuleType.OFFLINEQUERY);

    	}
    	t.commit();
    }
    
    void selectPendingQueries() {
    	
		manager = JpaUtil.getEntityManager();
		Session session = manager.unwrap(Session.class);
		offlineQueries=new OfflineQueries(manager);

    	try {
    			
    			if ( exec.size() >= maxRun ) {
    				return;
    			}
    			
		    	listPendingQueries=offlineQueries.allPendingDeamon(environment);
		    	
		    	for ( OfflineQuery offQry : listPendingQueries) {		    		
		    		if ( exec.size() < maxRun ) {
			            log( "Offline Query Selected. Id:"+offQry.getId() );
						Runnable worker = new RunQuery(offQry.getId(), offQry.getHostName(), offQry.getDatabaseName(), offQry.getSqlStatement());
						Future<?> f=executor.submit(worker);
						RunningQuery rq = new RunningQuery();
						rq.setExecution(f);
						rq.setId(offQry.getId());
						exec.add(rq);    							
		    		} else {
		    			break;
		    		}
		    	}
		    	
    	} catch (Exception e) {
    		e.printStackTrace();
    		logErr(""+e);
    		System.out.println("Error when checking pending requests");
    	} finally {
    		manager.close();
    	}
    	
    }
    
    void checkQueriesForKill() {    	   	    	
    	
    }
    
    public static class CleanFiles implements Runnable {
    	
        public void run() {
        	
        }
		
    }
    
    public static class CheckQueries extends Thread {
    	
    	List<RunningQuery> exec;
    	
    	CheckQueries(List<RunningQuery> exec1) {
    		this.exec=exec1;
    	}
    	
    	EntityManager manager;
    	private OfflineQueries offlineQueries;
    	private WriteLog log;
    	
    	DMSIIConnections dmsiiConn = new DMSIIConnections();

    	public void run() {
				    	
	    	while ( true ) {

	    		manager = JpaUtil.getEntityManager();
	    		Session session = manager.unwrap(Session.class);
	    		offlineQueries=new OfflineQueries(manager);
				
	    		try {
	    			log=new WriteLog(manager);
				} catch (Exception e1) {				
					e1.printStackTrace();
		    		logErr(""+e1);
				}

	    		try { 	    		
		        	List<OfflineQuery> listRunningQueries=offlineQueries.markedToKill(null);
		        	for (OfflineQuery offQry: listRunningQueries) {
		        		for ( RunningQuery rq : exec ) {
			          	    if ( rq.getId() == offQry.getId() ) {
				          	    if ( ! rq.getExecution().isDone()  ) {
				          	    	
//				          	    	DMConnection c=dmsiiConn.getDMConnection(offQry.getId());
//				          	    	if ( c != null && c.isConnected() ) {
//				          	    		c.closeSocketconnection();
//				          	    	}
				          	    	
				          	    	dmsiiConn.removeConnection(offQry.getId());
				          	    	
				          	    	rq.getExecution().cancel(true);
				          	    	
						    		Transaction t=session.beginTransaction();
				            	    offQry.setMessage(offQry.getMessage()+" - Query aborted by request(1) ");	
				            	    offQry.setStatus("A");
				            	    offlineQueries.update(offQry);
				              	    log.writeLogTable("Offline Query id "
				            				+ offQry.getId() 
				            				+": Query aborted by deamon: clearRunningQueries() method", MessageType.ERROR, ModuleType.OFFLINEQUERY);
						        	t.commit();			
				          	    }
			          	    	rq.getExecution().cancel(true);
			          	    }
		        		}
		        	}
	    		} catch (Exception e) {
	    			log("Error in CheckQueries class "+e);
	    			logErr("Error in CheckQueries class "+e);
		    		e.printStackTrace();
	    		}

	    		manager.close();
	    		
	    		try {
	    			Thread.sleep(20000);
	    		} catch (Exception e) {
	    			log("Error in Sleep "+e);
	    			logErr("Error in Sleep "+e);
		    		e.printStackTrace();
	    			
	    		}

	    	}
			
		}

    	
    }
    
    public static class RunQuery implements Runnable {
    
	private DMConnection conn ;
	
	private List<ColumnModel> columns=new ArrayList<ColumnModel>();
	private List<String> cols1=new ArrayList<String>();
	ArrayList rows = new ArrayList();
	
	String errorMsg="";

	int numRows = 0;
	    	
    double time;
    String fileName;
    
    int id; 
    String hostname,
    	   database,
           sql;
    
	private OfflineQueries offlineQueries;
	
	private Parameters params;
	private Parameter param;
	
	private WriteLog log;
	
	EntityManager manager;
	
	DMSIIConnections dmsiiConn = new DMSIIConnections();

	RunQuery(int id, String hostname, String databaseName, String sqlStatement) {
    	this.id=id;
    	this.hostname=hostname;
    	this.database=databaseName;
    	this.sql=sqlStatement;
    }
    
    public void run() {
    	    	
    	errorMsg=null;
    	String suspendPendingQueries="N";
    	
    	fileName=String.valueOf(id)+".csv";
    	
    	manager = JpaUtil.getEntityManager();
		Session session = manager.unwrap(Session.class);

        Hostnames hostnames=new Hostnames(manager);
        Hostname hn=hostnames.byHostname(hostname);
        
        String hostconn=hostname;
        
        if ( hn.getServerName() != null ) {
        	hostconn= hn.getServerName();
        }	

		DMConnectParams p = McpSqlParameter.getParameter(database, hostconn);
        
        //connect(p, null);
        

        long startTime = System.nanoTime();
        
		OfflineQuery offQry=null;
		
		try {
        	
        	offlineQueries=new OfflineQueries(manager);
        	log=new WriteLog(manager);
        	params=new Parameters(manager);
        	
        	param=params.byHostname(hostname);
        	
        	Environments environments = new Environments(manager);
        	Environment env = environments.byEnvironment(environment);

        	suspendPendingQueries=env.getSuspendPendingQueries();
        	offQry=offlineQueries.byId(id);

        	log("Starting offline query "+offQry.getId());


        	conn = new DMConnection();
        	
        	dmsiiConn.addConnection(id, conn, new Timestamp(System.currentTimeMillis()), env.getOfflineQueryTimeout());

            this.conn.connect(p);
            this.conn.open(p);
            this.conn.setIsolationLevel(1);
            
            log("Database "+offQry.getDatabaseName()+" opened for id "+offQry.getId()+". MixNum="+conn.getMixNum());

        	Transaction t=session.beginTransaction();
    		offQry.setProcessedDate(new Timestamp(System.currentTimeMillis()));
    		offQry.setStatus("R");
    		offQry.setMixNum(conn.getMixNum());
    		offlineQueries.update(offQry);
      	    log.writeLogTable("Offline Query Selected. Id:"+offQry.getId(), MessageType.SUCCESS, ModuleType.OFFLINEQUERY);
    		t.commit();

            DMStatement stmt = conn.createStatement();
            
        	startTime = System.nanoTime();
        	DMResultSet rs = stmt.executeQuery(sql);
        	
        	log("Query for id "+offQry.getId()+ " executed, go to fetch:"+sql);

        	numRows = 0;
        	fetch(rs, startTime, offQry.getId());

        	log("Query for id "+offQry.getId()+ " , 2");

        	time = (float)((System.nanoTime()-startTime)/1000000000.0);
        	stmt.close();
        	
        } catch (Exception e) {
        	
        	log("Query for id "+offQry.getId()+ " , 3");

        	log("Query for id "+offQry.getId()+", error Statement "+e);
            log( "Error while processing Id:"+offQry.getId()+":"+e.getMessage() );
            
            try {
				if ( dmsiiConn.hasExpired(offQry.getId()) ) {
		        	errorMsg="Timeout exceeded, query aborted";  
				} else {
		        	errorMsg=e.getMessage();  
		        	if ( errorMsg == null ) {
		        		errorMsg="Query aborted by request(1)";
		        	}
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
        	e.printStackTrace();
    		logErr("3:"+e);
        	if ( e.getMessage().toUpperCase().indexOf("LIMIT") > -1 ) {
        		
        	}

        }
        finally {
           	
        	log("Query for id "+offQry.getId()+ " , 4");

        	boolean hasExpired=false;
    		try {
    			hasExpired=dmsiiConn.hasExpired(offQry.getId());
    			dmsiiConn.removeConnection(offQry.getId());
                log("Database "+offQry.getDatabaseName()+" closed for id "+offQry.getId());
    		} catch (Exception e1) {
    			log("Error when trying to close the MCP connection:"+e1);
    		}

    		Transaction t=session.beginTransaction();
        	
    		if (! session.getTransaction().isActive() ) {
        		t=session.beginTransaction();
    		} else {
    			t=session.getTransaction();
    		}

    		time = (float)((System.nanoTime()-startTime)/1000000000.0);

    		offQry=offlineQueries.byId(id);
    		
    		offQry.setNumberOfReturnedRecords(numRows);
    		offQry.setExecutionTime((float)time);
    		offQry.setEndDate(new Timestamp(System.currentTimeMillis()));
    		if ( errorMsg != null ) {
    			if ( offQry.getMessage() == null ) {
        			offQry.setMessage(errorMsg);    				
    			} else {
        			offQry.setMessage(offQry.getMessage()+"("+errorMsg+")");
    			}
        		offQry.setStatus("A");
    		} else {
    			offQry.setStatus("C");
    		}
    		offlineQueries.update(offQry);
    		
    		if ( hasExpired && suspendPendingQueries.equals("Y")) {
        		suspendOfflineQueries(manager, offQry);
    		}
    		
    		if ( errorMsg != null ) {    			
          	    log.writeLogTable("Offline Query id " + id +" for database "+offQry.getDatabaseName()+": "+errorMsg, MessageType.ERROR, ModuleType.OFFLINEQUERY);
    		} else {
          	    log.writeLogTable("Offline Query id " + id + " processed for database "+offQry.getDatabaseName(), MessageType.SUCCESS, ModuleType.OFFLINEQUERY);
    		}
    		t.commit();
    		
        	log("End for offline query "+offQry.getId());

        	manager.close();
    		
        	for (int i=0;i<exec.size();i++) {
        		if ( exec.get(i).getId()==id ) {
        			exec.remove(i);
        			return;
        		}
        	}
        	

       } 
        	

    }
    
    private void suspendOfflineQueries(EntityManager manager, OfflineQuery oq ) {
    	
    	int recs=manager.createNativeQuery("update offline_queries set status = 'S' where user_id='"+oq.getUserId()+"' and database_name='"+oq.getDatabaseName()+"' and status='P'").executeUpdate();
    	
    	log("   ABORT id "+oq.getId()+": "+recs+" queued Offline Queries were changed to Suspended for "+oq.getUserId()+" Database "+oq.getDatabaseName());
    	
    }
        
    private boolean fetch(DMResultSet rs, long startTime, int id) throws Exception {
        boolean hasLobs = false;
        
        log("Query id "+id+ ", file to be created:"+param.getResultFolder()+"/"+fileName);
        
        Path path = Paths.get(param.getResultFolder()+"/"+fileName); 
        if ( Files.exists(path) ) {
        	Files.delete(path);
        }
        BufferedWriter writer = Files.newBufferedWriter(path,  Charset.forName("cp1252"),   StandardOpenOption.CREATE_NEW);

        log("Query id "+id+ ", reading records");

        try {
        	
        	
          DMItemDescription[] desc = rs.getDescription();

          columns=new ArrayList<ColumnModel>(); 
          cols1=new ArrayList<String>();
          rows = new ArrayList();
          StringBuilder sb; 
          numRows=0;
          
          try {
            while (true) {
              Object[] values = rs.fetch();
              if (values == null) {
            	  log("End of resultset = "+numRows+" records");  
                break;
              }
              
//              System.out.println("Record n."+ ++j);
              int cols = values.length;
              sb=new StringBuilder();

              if ( numRows==0) {
	              for (int i = 0; i < cols; i++) {
	        		  columns.add(new ColumnModel(desc[i].getName().toUpperCase(), values));
	        		  cols1.add(desc[i].getName().toUpperCase());
	        		  if ( i > 0 ) {
	        			  sb.append(";");
	        		  }
	        		  sb.append(desc[i].getName().toUpperCase());
	        	  }
	        	  writer.write(sb.toString()+"\n");
              }
          	  sb=new StringBuilder();  
              for (int i = 0; i < cols; i++) {
            	  
                //System.out.println(" Column:"+desc[i].getName()+" "+desc[i].getJavaTypeString()+" "+ values[i]);
                     	  
       		    if ( i > 0 ) {
       		    	sb.append(";");
        		}
            	
                if (desc[i].getSqlType() == 1) {
                	if (values[i] != null ) {
                		values[i] = values[i].toString().trim() ;
                	} else {
                		values[i]="<null>";
                	}
                }
                if (values[i] == null) {                 
                  values[i] = "<null>";
                  sb.append(";");
                }
                else if (values[i] instanceof DMLocator) {
                  
                  if (desc[i].getSqlType() == 2004) {
                    
                    hasLobs = true;
                    values[i] = new MCPSQLColLob(1, (DMLocator)values[i]);
                  } 
                  
                  if (desc[i].getSqlType() == 2005) {
                    
                    hasLobs = true;
                    values[i] = new MCPSQLColLob(2, (DMLocator)values[i]);
                  } 
                } else {
                  sb.append(String.valueOf(values[i]));
                }
              } 
              rows.add(values);
              writer.write(sb.toString()+"\n");
              numRows++;
            } 
          } catch (DMProviderException e) {
        	  log("Error 1:"+e);
        	  logErr("Error 1:"+e);
        	  errorMsg=e.getMessage();
        	  return hasLobs;
          } catch (Exception e) {
        	  log("Error 2:"+e);
        	  logErr("Error 2:"+e);
        	  errorMsg=e.getMessage();
        	  return hasLobs;
          } 
          
        }
        finally {
          
            log("Query id "+id+ ", closing file "+param.getResultFolder()+"/"+fileName);

            writer.flush();
            writer.close();
        	
        } 
        
        
        return hasLobs;
      }
        
    }
    
}
