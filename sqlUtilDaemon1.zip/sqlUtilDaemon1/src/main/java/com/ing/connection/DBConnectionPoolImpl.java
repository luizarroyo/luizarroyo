package com.ing.connection;


import java.util.List;

import com.unisys.mcpsql.server.Connection;



public interface DBConnectionPoolImpl {
	
	DMConn getDmConnection(String userId, String sessionId, String hostname, String databaseName, String sqlText, boolean selectDatabases) throws Exception;
	DMConnect getConnection(String userId, String sessionId, String hostname, String databaseName) throws Exception;
	DMConnect getConnection(String userId, String sessionId, String hostname, String databaseName, String sqlText, boolean selectDatabases) throws Exception;
    
	boolean  releaseDmConnection(DMConn connection);
	boolean  releaseConnection(DMConnect connection);
    
    List<DMConn> getConnectionPool();
    
    int getSize();
    
    String getUrl();
    
    String getUser();

    String getPassword();
    
    void shutdown() throws  Exception;;
    
}
