package com.ing.connection;

import com.unisys.mcpsql.provider.DMAbstractStatement;
import com.unisys.mcpsql.provider.DMItemDescription;
import com.unisys.mcpsql.provider.DMProviderException;
import com.unisys.mcpsql.provider.DMStatement;
import com.unisys.mcpsql.server.Statement;
import java.util.ArrayList;















public class MCPSQLStatement1
  implements Statement
{
  static final int NONE = 0;
  static final int PREPARED = 1;
  static final int CLOSED = 2;
  int statementState = 0;

  
  public DMAbstractStatement stmt;
  
  DMProviderException exception;

  
  public Exception getException() { return this.exception; }

  
  boolean limitExceeded = false;
  
  ArrayList data;
  
  public boolean rowLimitExceeded() { return this.limitExceeded; }








  
  public ArrayList getData() { return this.data; }






  
  public DMItemDescription[] getResultSetDescription() { return this.stmt.getResultSetDescription(); }






  
  public DMItemDescription[] getParameterDescription() { return ((DMStatement)this.stmt).getParamDescription(); }

  
  int rowCount = -1;





  
  public int getRowCount() { return this.rowCount; }






  
  public String getQDumpString() { return ((DMStatement)this.stmt).getQDumpString(); }






  
  public String getQGraphString() { return ((DMStatement)this.stmt).getQGraphString(); }



  
  MCPSQLStatement1() {}



  
  public MCPSQLStatement1(DMAbstractStatement stmt) { this.stmt = stmt; }


  
  MCPSQLStatement1(DMStatement stmt, int rowCount) {
    this.stmt = stmt;
    this.rowCount = rowCount;
  }




  
  public String[] getColumnNames() {
    DMItemDescription[] description = this.stmt.getResultSetDescription();
    if (description == null || description.length == 0)
    {
      return null;
    }
    int cols = description.length;
    String[] names = new String[cols];
    for (int i = 0; i < cols; i++)
    {
      names[i] = description[i].getName();
    }
    return names;
  }


  
  public void close() throws Exception { 
	  stmt.close(); 
  }
  
}
