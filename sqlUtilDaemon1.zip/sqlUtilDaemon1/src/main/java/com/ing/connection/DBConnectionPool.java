package com.ing.connection;


import java.sql.Timestamp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.hibernate.Session;

import com.ing.sql.model.Hostname;
import com.ing.sql.model.Parameter;
import com.ing.sql.repository.Hostnames;
import com.ing.sql.repository.Parameters;
import com.ing.sql.util.MessageType;
import com.ing.sql.util.ModuleType;
import com.ing.sql.util.Transactional;
import com.ing.sql.util.WriteLog;
import com.unisys.mcpsql.provider.DMConnectParams;

public class DBConnectionPool implements DBConnectionPoolImpl {

    private final String url="";
    private final String user="";
    private final String password="";
    private final String database="";
    
    private static final int INITIAL_POOL_SIZE = 0;
    private final int MAX_POOL_SIZE = 3;

    private static List<DMConn> DmConnectPool = new ArrayList<>();
    private static List<DMConn> usedDmConnects = new ArrayList<>();

    private static List<DMConnect> connectionPool = new ArrayList<>();
    private static List<DMConnect> usedConnections = new ArrayList<>();

    private static boolean debug=true;
    
    private static int connectionId=0;
    private static int connectionIdConn=0;
    
    private static boolean timeoutExecution=false;
    @Inject
    private static Parameters parameters;
    
    @Inject
    private static Hostnames hostnames;

    @Inject
    private static WriteLog log;
    
    private TimeoutControl timeoutControl;
    
    public DBConnectionPool()  {
        
//        this.DmConnectPool = new ArrayList<>(INITIAL_POOL_SIZE);
        if ( debug ) {
        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": <<debug>> Connection pool initialized");
        }

        if ( ! timeoutExecution ) {
	        timeoutControl=new TimeoutControl(DmConnectPool, connectionPool, usedDmConnects);
	        timeoutControl.start();
	        timeoutExecution=true;
        }
        
    }

    public synchronized  DMConn getDmConnection(String userId, String sessionId, String hostname, String databaseName, String sqlText, boolean selectDatabases) throws Exception {
    	
        if (DmConnectPool.isEmpty()) {
            if (usedDmConnects.size() < MAX_POOL_SIZE) {
            	DmConnectPool.add(createDmConnection(databaseName, hostname));
            } else {
                throw new RuntimeException("Maximum pool size reached for DmConnect, no available connections!");
            }
        }

        if ( ! selectDatabases ) {
	        for (DMConn c : usedDmConnects) {
	        	if ( c.getUserId().equals(userId) ) {
	        		throw new RuntimeException("The user "+userId+" has a query in progress... The previous one should be finished:"+c.getDatabasename()+", started at "+c.getStartTime());
	        	}
	        }
        }

        DMConn connection=null;
        for ( int i=0; i< DmConnectPool.size(); i++) {
	        if ( DmConnectPool.get(i).getDatabasename().equals(databaseName) && DmConnectPool.get(i).getHostname().equals(hostname) ) {
	        	connection = DmConnectPool.remove(i);
		        connection.setSessionId(sessionId);
		        connection.setUserId(userId);
		        connection.setDatabaseName(databaseName);
		        connection.setHostname(hostname);
		        connection.setSqlText(sqlText);
		        connection.setStartTime(new Timestamp(System.currentTimeMillis()));
		        break;
	        }
        }
        if ( connection == null ) {
            if (usedDmConnects.size() < MAX_POOL_SIZE) {
	        	connection = createDmConnection(databaseName, hostname);
		        connection.setSessionId(sessionId);
		        connection.setUserId(userId);
		        connection.setDatabaseName(databaseName);
		        connection.setHostname(hostname);
		        connection.setSqlText(sqlText);
		        connection.setStartTime(new Timestamp(System.currentTimeMillis()));
            } else {
                throw new RuntimeException("Maximum pool size reached for DmConnect("+hostname+"-"+databaseName+"), no available connections!");
            }
        }
       
        usedDmConnects.add(connection);
        
        if ( debug ) {
        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
        			": <<debug>> DMConnect selected("+databaseName+"): "+getNumberOfDmConnects(databaseName)+" remaining, "+getNumberOfUsedDmConnects(databaseName)+" in use");
        }

        return connection;
    }

    @Override
    public synchronized  DMConnect getConnection(String userId, String sessionId, String hostname, String databaseName, String sqlText, boolean selectDatabases) throws Exception {
    	return getConnection(userId, sessionId, hostname, databaseName);
    }
    @Override
    public synchronized  DMConnect getConnection(String userId, String sessionId, String hostname, String databaseName) throws Exception {
    	
        DMConnect connection = null;
    	if (databaseName == null ) {
    		databaseName="";
    	}
    	
        if (connectionPool.isEmpty()) {
//            if (usedConnections.size() < MAX_POOL_SIZE) {
        	    connection = createConnection( databaseName, hostname);
        	    if (connection == null ) {
                	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
                			": <<debug>> ** Error getConnection ("+databaseName+")");
                	return null;
	        	}
        	    connectionPool.add(connection);
//            } else {
//                throw new RuntimeException("Maximum pool size reached for Connection, no available connections!");
//            }
        }

        for ( int i=0; i< connectionPool.size(); i++) {
	        if ( connectionPool.get(i).getDatabaseName().equals(databaseName) && connectionPool.get(i).getHostname().equals(hostname) ) {	        	
	        	connection = connectionPool.remove(i);
		        connection.setSessionId(sessionId);
		        connection.setUserId(userId);
		        connection.setDatabaseName(databaseName);
		        connection.setHostname(hostname);
		        connection.setStartTime(new Timestamp(System.currentTimeMillis()));
		        break;
	        }
        }
        if ( connection == null ) {
            if (usedConnections.size() <= MAX_POOL_SIZE) {
            	
               	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
            			": <<debug>> ** Before creating the service connection  ("+hostname+"-"+databaseName+")");

	        	connection = createConnection(databaseName, hostname);
	        	if (connection == null ) {
                	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
                			": <<debug>> ** Error getConnection ("+databaseName+")");
                	return null;
	        	}
		        connection.setSessionId(sessionId);
		        connection.setUserId(userId);
		        connection.setDatabaseName(databaseName);
		        connection.setHostname(hostname);
		        connection.setStartTime(new Timestamp(System.currentTimeMillis()));
            } else {
                if ( debug ) {
                	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
                			": <<debug>> ** Connection selected("+databaseName+"): "+getNumberOfConnections(connection.getDatabaseName())+" remaining, "+getNumberOfUsedConnections(connection.getDatabaseName())+" in use");
                }
                throw new RuntimeException("Maximum pool size reached for Connection("+hostname+"-"+databaseName+"), no available work connections");
            }
        }

        usedConnections.add(connection);
        
        if ( debug ) {
        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
        			": <<debug>> ** Connection selected("+databaseName+"): "+getNumberOfConnections(connection.getDatabaseName())+" remaining, "+getNumberOfUsedConnections(connection.getDatabaseName())+" in use");
        }

        return connection;
    }

    public synchronized void  cleanDmConnection(DMConn connection) {    	
    	connection.cleanFields();
    	connection.setStartTime(new Timestamp(System.currentTimeMillis()));
    }

    public synchronized void  cleanConnection(DMConnect connection) {    	
    	connection.cleanFields();
    	connection.setStartTime(new Timestamp(System.currentTimeMillis()));
    }
    
    
    public synchronized boolean  releaseDmConnection(DMConn connection) {
    	
    	connection.cleanFields();
    	connection.setStartTime(new Timestamp(System.currentTimeMillis()));
    	
    	if ( connection.isConnected() ) {
    		DmConnectPool.add(connection);
    		
//workaround to avoid lock all records selected
//    		try {
//    			connection.closeSocketconnection();
//    		} catch (Exception e) {
//    			System.out.println("Close Socket error(releaseDmConnect)="+e);
//    		}
    	}
        
        if ( debug ) {
        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
        			": <<debug>> DMConnect released("+connection.getDatabasename()+"): "+getNumberOfDmConnects(connection.getDatabaseName())+" availables , "+
        			                                                                       (getNumberOfUsedDmConnects(connection.getDatabaseName()) - 1)+" in use");
        }

        return usedDmConnects.remove(connection);
    }

    public synchronized void  removeDmConnect(DMConn connection) {
    	
    	if ( connection.getSqlText().equals("") ) {
    		for ( DMConn conn : DmConnectPool) {
    			if ( conn.getConnectionId() == connection.getConnectionId()) {
    				DmConnectPool.remove(connection);
    				return;
    			}
    		}
    	} else {
    		for ( DMConn conn : usedDmConnects ) {
    			if ( conn.getConnectionId() == connection.getConnectionId()) {
    				usedDmConnects.remove(connection);
    			}
    		}
    	}
        
        if ( debug ) {
        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
        			": <<debug>> DMConnect removed("+connection.getDatabasename()+"): "+getNumberOfDmConnects(connection.getDatabasename())+" availables , "+
        			                                                                      (getNumberOfUsedDmConnects(connection.getDatabasename()) - 1)+" in use");
        }
        
    }
    
    public static synchronized void  killDmConnection(int connectionId) {
    	    	
//    	connection.cleanFields();
    	try {
	    	for ( DMConn conn: DmConnectPool ) {
	    		if ( conn.getConnectionId() == connectionId ) {
	    			conn.close();
	    			//conn.closeSocketconnection();
	    			DmConnectPool.remove(conn);
	    			return;
	    		}
	    	}
	    	for ( DMConn conn: usedDmConnects ) {
	    		if ( conn.getConnectionId() == connectionId ) {
	    			//conn.close();
	    			conn.closeSocketconnection();
	    			usedDmConnects.remove(conn);
	    			return;
	    		}
	    	}
    	} catch (Exception e) {
    		System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": <<debug>> Error Kill Connection: "+e.getMessage());
    		e.printStackTrace();
    	}
        
//        if ( debug ) {
//        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": <<debug>> DMConnect killed ("+connectionId+"): "+DmConnectPool.size()+" availables , "+(usedDmConnects.size() - 1)+" in use");
//        }
        
    }

    public static synchronized void  killConnection(int connectionId) {
    	
//    	connection.cleanFields();
    	try {
	    	for ( DMConnect conn: connectionPool ) {
	    		if ( conn.getConnectionId() == connectionId ) {
	    			conn.c.close();
	    			connectionPool.remove(conn);
	    			return;
	    		}
	    	}
    	} catch (Exception e) {
    		System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": <<debug>> Error Kill Service Connection: "+e.getMessage());
    		e.printStackTrace();
    	}
        
//        if ( debug ) {
//        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": <<debug>> Service Connection Killed ("+connectionId+"): "+DmConnectPool.size()+" availables , "+(usedDmConnects.size() - 1)+" in use");
//        }
        
    }

    @Override
    public synchronized boolean releaseConnection(DMConnect connection) {
        
    	connectionPool.add(connection);
    	connection.cleanFields();
    	connection.setStartTime(new Timestamp(System.currentTimeMillis()));
        
        usedConnections.remove(connection);
        if ( debug ) {
        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+
        			": <<debug>> ** Connection released("+connection.getDatabaseName()+"): "+getNumberOfConnections(connection.getDatabaseName())+" remaining, "+getNumberOfUsedConnections(connection.getDatabaseName())+" in use");
        }
        
        return true;

    }

    private static DMConn createDmConnection(String database, String hostname) throws Exception {
        return getDmConnection(database, hostname);
    }

    private static DMConnect createConnection(String database, String hostname) throws Exception {
        return getConnection(database, hostname);
    }

    @Override
    public int getSize() {
        return DmConnectPool.size() + usedDmConnects.size();
    }

    @Override
    public List<DMConn> getConnectionPool() {
        return DmConnectPool;
    }
    
    public static List<DMConn> getDmConnection() {
        return DmConnectPool;
    }

    public static List<DMConn> getUsedDmConnection() {
        return usedDmConnects;
    }

    public static List<DMConnect> getServiceConnection() {
        return connectionPool;
    }

    @Override
    public String getUrl() {
        return url;
    }

    @Override
    public String getUser() {
        return user;
    }

    @Override
    public String getPassword() {
        return password;
    }
    
    @Override
    public void shutdown() throws Exception {
        usedDmConnects.forEach(this::releaseDmConnection);
        for (DMConn c : DmConnectPool) {
				c.close();
        }
        DmConnectPool.clear();

        usedConnections.forEach(this::releaseConnection);
        for (DMConnect c : connectionPool) {
				c.getConnection().close();
        }
        connectionPool.clear();
    }
	
    static DMConn getDmConnection(String database, String hostname ) throws Exception  {
    	
        EntityManager em=JpaUtil.getEntityManager();
        parameters=new Parameters(em);
        Parameter parameter=parameters.byHostname(hostname);

        hostnames=new Hostnames(em);
        Hostname hn=hostnames.byHostname(hostname);
        
        em.close();

        DMConnectParams p;
        
        if ( hn.getServerName() == null ) { 
        	p = McpSqlParameter.getParameter(database, hostname);
        } else {
        	p = McpSqlParameter.getParameter(database, hn.getServerName());
        }	
    	
        DMConn conn = new DMConn();
    	
        conn.connect(p);
        conn.open(p);
        
        conn.setIsolationLevel(1);
        conn.setAutoCommit(true);
        
        connectionId++;
        conn.setConnectionId(connectionId);
        conn.setDatabaseName(database);
        conn.setHostname(hostname);
        conn.setTimeout(parameter.getConnectionTimeout());
        conn.setStartTime(new Timestamp(System.currentTimeMillis()));
        
        if ( debug ) {
        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": <<debug>> New DMConnect Created for "+database + " ID="+connectionId);
        }

        return conn;
        
    }

    @Transactional
    static DMConnect getConnection(String database, String hostname )  {
    	
        EntityManager em=JpaUtil.getEntityManager();
        parameters=new Parameters(em);
        Parameter parameter=parameters.byHostname(hostname);

        hostnames=new Hostnames(em);
        Hostname hn=hostnames.byHostname(hostname);


        DMConnectParams p;
        
        if ( hn.getServerName() == null || hn.getServerName().contentEquals("") ) {
        	p = McpSqlParameter.getParameter(database, hostname);
        } else {
        	p = McpSqlParameter.getParameter(database, hn.getServerName());
        }	
    	
        try {
        DMConnect dmconn = new DMConnect(p);
    	
    	dmconn.setConnection(p);
    	
        dmconn.getConnection().connect();

        connectionIdConn++;
        
        //dmconn.setIsolationLevel(4);
        //conn.setAutoCommit(false);

        dmconn.setConnectionId(connectionIdConn);
        dmconn.setDatabaseName(database);
       	dmconn.setHostname(hostname);
        dmconn.setTimeout(parameter.getConnectionTimeout());

        if ( debug ) {
        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": <<debug>> New Service Connection Created for "+hostname+"-"+database+ " ID="+connectionIdConn);
        }

        em.close();
        return dmconn;
        
        } catch ( Exception e ) {
        	
        	try {
				log=new WriteLog(em);
			} catch (Exception e1) {				
				e1.printStackTrace();
			}
    		log.getManager().unwrap(Session.class).beginTransaction();
    		log.writeLogTable("Error when creating a service connection for "+hostname+"-"+database+ ":"+e, MessageType.ERROR, ModuleType.SQL);
    		log.getManager().unwrap(Session.class).getTransaction().commit();
    		if ( em.isOpen() ) {
        		em.close();
        	}

        	System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": <<debug>> ERROR  getConnection - New Service Connection for "+hostname+"-"+database+ ":"+e);
        	return null;
        }
    }

    private int getNumberOfDmConnects(String database) {
    	int i=0;
    	for (DMConn con: DmConnectPool) {
    		if ( con.getDatabaseName().equals(database) ) {
    			i++;
    		}
    	}
    	return i;
    }

    private int getNumberOfUsedDmConnects(String database) {
    	int i=0;
    	for (DMConn con: usedDmConnects) {
    		if ( con.getDatabaseName().equals(database) ) {
    			i++;
    		}
    	}
    	return i;
    }

    private int getNumberOfConnections(String database) {
    	int i=0;
    	for (DMConnect con: connectionPool) {
    		if ( con.getDatabaseName().equals(database) ) {
    			i++;
    			break;
    		}
    	}
    	return i;
    }

    private int getNumberOfUsedConnections(String database) {
    	int i=0;
    	for (DMConnect con: usedConnections) {
    		if ( con.getDatabaseName().equals(database) ) {
    			i++;
    			break;
    		}
    	}
    	return i;
    }

}
