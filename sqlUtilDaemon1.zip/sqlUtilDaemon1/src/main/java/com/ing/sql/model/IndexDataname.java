package com.ing.sql.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INDEXES_DATANAMES")
public class IndexDataname implements Serializable {

	private static final long serialVersionUusercode = 1L;
	
	@Id
	@GeneratedValue
	@Column(name = "ID", insertable = false )
	private int id;
	@Column(name = "DATABASE_NAME",length = 17, nullable = false)
	private String databaseName;
	@Column(name = "DATASET_NAME",length = 17, nullable = false)
	private String datasetName;
	@Column(name = "INDEX_NAME",length = 17, nullable = false)
	private String indexName;
	@Column(name = "DATANAME",length = 17)
	private String dataname;
	@Column(name = "asc_desc",length = 6, nullable = false)
	private String setSubset;
	@Column(name = "FIELD_SEQUENCE",length = 20, nullable = false)
	private int fieldSequence;
	
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	public String getDatasetName() {
		return datasetName;
	}
	public void setDatasetName(String dataset_name) {
		this.datasetName = dataset_name;
	}
	public String getDataname() {
		return dataname;
	}
	public void setDataname(String dataname) {
		this.dataname = dataname;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSetSubset() {
		return setSubset;
	}
	public void setSetSubset(String setSubset) {
		this.setSubset = setSubset;
	}	
	public String getIndexName() {
		return indexName;
	}
	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}
	public int getFieldSequence() {
		return fieldSequence;
	}
	public void setFieldSequence(int fieldSequence) {
		this.fieldSequence = fieldSequence;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IndexDataname other = (IndexDataname) obj;
		if (id != other.id)
			return false;
		return true;
	}

	
	

}
