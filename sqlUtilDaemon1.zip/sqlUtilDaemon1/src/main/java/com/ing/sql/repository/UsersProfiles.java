package com.ing.sql.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.ing.sql.model.UserProfile;
import com.ing.sql.model.UserProfilePk;

public class UsersProfiles implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public UsersProfiles(EntityManager manager) {
		this.manager = manager;
	}

	public UserProfile byId(UserProfilePk id) {
		return manager.find(UserProfile.class, id);
	}
	
	public List<String> test(String descr) {
		TypedQuery<String> query = manager.createQuery(
				"select distinct descr from lanc "
				+ "where upper(descr) like upper(:descr)", 
				String.class);
		query.setParameter("descr", "%" + descr + "%");
		return query.getResultList();
	}
	
	public List<UserProfile> byUserId(String userId) {
		TypedQuery<UserProfile> query = manager.createQuery(
				"from UserProfile where user_id = :user order by profile_Name", UserProfile.class);
		query.setParameter("user",  userId );
		return query.getResultList();
	}

	public List<String> profiles(String userId) {
		TypedQuery<String> query = manager.createQuery(
				"select up.userProfilePk.profileName from UserProfile up where up.userProfilePk.userId = :user order by up.userProfilePk.profileName", String.class);
		query.setParameter("user", userId );
		return query.getResultList();
	}

	public List<String> notProfiles(String userId) {
		TypedQuery<String> query = manager.createQuery(
				"Select p.profileName from Profile p where p.profileName not in "+
		               " (select up.userProfilePk.profileName from UserProfile up where up.userProfilePk.userId = :user) order by p.profileName", String.class);
		query.setParameter("user", userId );
		return query.getResultList();
	}

	public List<String> users(String profileName) {
		TypedQuery<String> query = manager.createQuery(
				"select up.userProfilePk.userId from UserProfile up where up.userProfilePk.profileName = :profile order by up.userProfilePk.userId", String.class);
		query.setParameter("profile", profileName );
		return query.getResultList();
	}

	public List<String> notUsers(String profileName) {
		TypedQuery<String> query = manager.createQuery(
				"Select p.userId from User p where p.userId not in "+
		               " (select up.userProfilePk.userId from UserProfile up where up.userProfilePk.profileName = :profile) order by p.userId", String.class);
		query.setParameter("profile", profileName );
		return query.getResultList();
	}

	public List<UserProfile> all() {
		TypedQuery<UserProfile> query = manager.createQuery(
				"from UserProfile order by userId, profileName", UserProfile.class);
		return query.getResultList();
	}

	public void insert(UserProfile userProfile) {
		this.manager.persist(userProfile);
	}
	
	public UserProfile update(UserProfile userProfile) {
		return this.manager.merge(userProfile);
	}
	
	public void delete(UserProfile userProfile) {
		this.manager.remove(userProfile);
	}

	
	public void rollback() {
		if ( manager.getTransaction().isActive() ) {
			manager.getTransaction().rollback();
		}
	}
	

}