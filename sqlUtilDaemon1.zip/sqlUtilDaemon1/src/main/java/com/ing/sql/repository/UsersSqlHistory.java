package com.ing.sql.repository;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.ing.sql.model.UserHistory;
import com.ing.sql.model.UserHistoryPk;
import com.ing.sql.model.UserSqlHistory;

public class UsersSqlHistory implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public UsersSqlHistory(EntityManager manager) {
		this.manager = manager;
	}

	public UserSqlHistory byDatabase(String id) {
		return manager.find(UserSqlHistory.class, id);
	}
	
	public List<UserSqlHistory> allByUserDate(String userId, Date historyDate) {
		TypedQuery<UserSqlHistory> query = manager.createQuery(
			"from UserSqlHistory where USER_ID=:userId and ACTIVITY_DATE=:historyDate order by SQL_STATEMENT", 
			UserSqlHistory.class);
		query.setParameter("userId", userId);
		query.setParameter("historyDate", historyDate);
		return query.getResultList();
	}

	public List<UserSqlHistory> allByUser(String userId, String startDate, String filter) {
		TypedQuery<UserSqlHistory> query = manager.createQuery(
			"from UserSqlHistory where (USER_ID=:userId or :userId='') and activity_date <= :startDate and sql_statement like :filter order by ACTIVITY_DATE desc, SQL_STATEMENT", 
			UserSqlHistory.class);
		query.setParameter("userId", userId);
		query.setParameter("startDate", startDate+" 23:59:59");
		query.setParameter("filter", "%"+filter.trim()+"%");
		return query.getResultList();
	}
	
	public void insert(UserSqlHistory userSqlHistory) {
		this.manager.persist(userSqlHistory);
	}
	
	public void rollback() {
		if ( manager.getTransaction().isActive() ) {
			manager.getTransaction().rollback();
		}
	}
	
}
