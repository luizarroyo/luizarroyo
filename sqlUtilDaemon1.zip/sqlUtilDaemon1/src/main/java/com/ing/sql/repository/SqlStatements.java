package com.ing.sql.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.ing.sql.model.Database;
import com.ing.sql.model.SqlStatement;
import com.ing.sql.model.SqlStatementPk;
import com.ing.sql.model.UserHistory;

public class SqlStatements implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public SqlStatements(EntityManager manager) {
		this.manager = manager;
	}

	public SqlStatement bySqlStatementPk(SqlStatementPk id) {
		return manager.find(SqlStatement.class, id);
	}
	
	public List<SqlStatement> allByUser(String userId, String filter) {
		TypedQuery<SqlStatement> query = manager.createQuery(
			"from SqlStatement where (USER_ID = :userId or SECURITY='P') and sql_statement like :filter order by USER_ID, QUERY_NAME"
				, SqlStatement.class);
		query.setParameter("userId", userId);
		query.setParameter("filter", "%"+filter.trim()+"%");
		return query.getResultList();
	}

	public List<SqlStatement> all(String filter) {
		TypedQuery<SqlStatement> query = manager.createQuery(
			"from SqlStatement where sql_statement like :filter or :filter='' order by USER_ID, QUERY_NAME"
				, SqlStatement.class);
		query.setParameter("filter", filter.trim());
		return query.getResultList();
	}


	public void insert(SqlStatement sqlStatement) {
		this.manager.persist(sqlStatement);
	}
	
	public SqlStatement update(SqlStatement sqlStatement) {
		return this.manager.merge(sqlStatement);
	}
	
	public void delete(SqlStatement sqlStatement) {
		this.manager.remove(sqlStatement);
	}

	public void flush() {
		manager.flush();
	}
	
	public void rollback() {
		if ( manager.getTransaction().isActive() ) {
			manager.getTransaction().rollback();
		}
	}
	
}
