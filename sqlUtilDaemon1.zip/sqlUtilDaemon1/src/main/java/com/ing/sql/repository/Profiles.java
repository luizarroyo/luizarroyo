package com.ing.sql.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.ing.sql.model.Profile;
import com.ing.sql.model.Profile;

public class Profiles implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public Profiles(EntityManager manager) {
		this.manager = manager;
	}

	public Profile byProfileName(String id) {
		return manager.find(Profile.class, id);
	}
	
	public List<Profile> all(String filter) {
		TypedQuery<Profile> query = manager.createQuery("from Profile where profileName like :filter or :filter='' order by profileName", Profile.class);
		query.setParameter("filter", filter );
		return query.getResultList();
	}

	public List<String> allProfiles() {
		TypedQuery<String> query = manager.createQuery("select profileName from Profile order by profileName", String.class);
		return query.getResultList();
	}

	public List<String> profilesByUser(String userId) {
		TypedQuery<String> query = manager.createQuery("select profileName from Profile where userId=:userId order by profileName", String.class);
		query.setParameter("userID", userId );
		return query.getResultList();
	}

	public void insert(Profile profile) {
		this.manager.persist(profile);
	}
	
	public Profile update(Profile profile) {
		return this.manager.merge(profile);
	}
	
	public void delete(Profile profile) {
		this.manager.remove(this.manager.contains(profile) ? profile : this.manager.merge(profile));
//		this.manager.remove(profile);
	}

	
	public void rollback() {
		if ( manager.getTransaction().isActive() ) {
			manager.getTransaction().rollback();
		}
	}

	public EntityManager getManager() {
		return manager;
	}

	public void setManager(EntityManager manager) {
		this.manager = manager;
	}
	

}
