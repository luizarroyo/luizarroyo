package com.ing.sql.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import org.hibernate.Transaction;

import com.ing.sql.model.UserHistory;
import com.ing.sql.model.UserHistoryPk;

public class UsersHistory implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public UsersHistory(EntityManager manager) {
		this.manager = manager;
	}

	public UserHistory byUserHistoryPk(UserHistoryPk id) {
		return manager.find(UserHistory.class, id);
	}
	
	public List<UserHistory> allByUser(String userId, String startDate) {
		TypedQuery<UserHistory> query = manager.createQuery(
			"from UserHistory where (USER_ID = :userId or :userId='' ) and ACTIVITY_DATE <= :startDate order by ACTIVITY_DATE desc"
				, UserHistory.class);
		query.setParameter("userId", userId);
		query.setParameter("startDate", startDate+" 23:59:59");
		return query.getResultList();
	}

	public void updateStatistics(UserHistoryPk id, int numberOfReturnedRecords, float timeOfProcessedQueries ) {
		UserHistory userHistory = byUserHistoryPk(id);
		if ( userHistory == null ) {
			userHistory = new UserHistory();
			userHistory.setUserHistoryPk(id);
			userHistory.setNumberOfProcessedQueries(1);
			userHistory.setNumberOfReturnedRecords(numberOfReturnedRecords);
			userHistory.setTimeOfProcessedQueries(timeOfProcessedQueries);
			this.manager.persist(userHistory);
		} else {
			userHistory.setNumberOfProcessedQueries(userHistory.getNumberOfProcessedQueries()+1);
			userHistory.setNumberOfReturnedRecords(userHistory.getNumberOfReturnedRecords()+numberOfReturnedRecords);
			userHistory.setTimeOfProcessedQueries(userHistory.getTimeOfProcessedQueries()+timeOfProcessedQueries);
			this.manager.merge(userHistory);			
		}
	}
	
	public void insert(UserHistory userHistory) {
		this.manager.persist(userHistory);
	}
	
	public void update(UserHistory userHistory) {
		this.manager.merge(userHistory);
	}

	public void delete(UserHistory userHistory) {
		this.manager.remove(userHistory);
	}
	
	public void rollback() {
		if ( manager.getTransaction().isActive() ) {
			manager.getTransaction().rollback();
		}
	}
	

}
