package com.ing.sql.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "USERS_ACTIVITIES")
public class UserHistory implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private UserHistoryPk userHistoryPk;
	
	@Column(name = "NUMBER_OF_PROCESSED_QUERIES", nullable = false)
	private int numberOfProcessedQueries;
	@Column(name = "TIME_OF_PROCESSED_QUERIES", nullable = false)
	private double timeOfProcessedQueries;
	@Column(name = "NUMBER_OF_RETURNED_RECORDS", nullable = false)
	private long numberOfReturnedRecords;
	
	public UserHistoryPk getUserHistoryPk() {
		return userHistoryPk;
	}
	public void setUserHistoryPk(UserHistoryPk userHistoryPk) {
		this.userHistoryPk = userHistoryPk;
	}
	
	public int getNumberOfProcessedQueries() {
		return numberOfProcessedQueries;
	}	
	public void setNumberOfProcessedQueries(int numberOfProcessedQueries) {
		this.numberOfProcessedQueries = numberOfProcessedQueries;
	}
	
	public double getTimeOfProcessedQueries() {
		return timeOfProcessedQueries;
	}
	public void setTimeOfProcessedQueries(double timeOfProcessedQueries) {
		this.timeOfProcessedQueries = timeOfProcessedQueries;
	}
	
	public long getNumberOfReturnedRecords() {
		return numberOfReturnedRecords;
	}
	public void setNumberOfReturnedRecords(long numberOfReturnedRecords) {
		this.numberOfReturnedRecords = numberOfReturnedRecords;
	}
	
	public String getUserId() {
		return userHistoryPk.userId;
	}
	
	public Date getHistoryDate() {
		return userHistoryPk.historyDate;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userHistoryPk == null) ? 0 : userHistoryPk.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserHistory other = (UserHistory) obj;
		if (userHistoryPk == null) {
			if (other.userHistoryPk != null)
				return false;
		} else if (!userHistoryPk.equals(other.userHistoryPk))
			return false;
		return true;
	}

	
}
