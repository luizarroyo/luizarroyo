package com.ing.sql.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

public class SqlStatementPk implements Serializable {
	
    @Column(name = "USER_ID",length = 6, nullable = false)
    protected String userId;
    @Column(name = "QUERY_NAME",length = 50, nullable = false)
    protected String queryName;
	@Column(name = "DATABASE_NAME",length = 17, nullable = true)
	private String databaseName;

    public SqlStatementPk() {}

    public SqlStatementPk(String userId, String queryName, String databaseName) {
        this.userId = userId;
        this.queryName = queryName;
        this.databaseName = databaseName;
    }
    
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((databaseName == null) ? 0 : databaseName.hashCode());
		result = prime * result + ((queryName == null) ? 0 : queryName.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SqlStatementPk other = (SqlStatementPk) obj;
		if (databaseName == null) {
			if (other.databaseName != null)
				return false;
		} else if (!databaseName.equals(other.databaseName))
			return false;
		if (queryName == null) {
			if (other.queryName != null)
				return false;
		} else if (!queryName.equals(other.queryName))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}

}
