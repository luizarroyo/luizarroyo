package com.ing.sql.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.ing.sql.model.ProfileLimits;
import com.ing.sql.model.User;

public class Users implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public Users(EntityManager manager) {
		this.manager = manager;
	}

	public User byUserId(String id) {
		return manager.find(User.class, id);
	}
	
	public List<User> all(String filter) {
		TypedQuery<User> query = manager.createQuery("from User where (userId like :filter or :filter='') order by userId", User.class);
	    query.setParameter("filter", filter);
		return query.getResultList();
	}

	public List<String> allUserId() {
		TypedQuery<String> query = manager.createQuery("Select userId from User order by userId", String.class);
		return query.getResultList();
	}

	public User getUserId(String user) {
		return manager.getReference(User.class, user);
	}

	public List<String> getDatabaseAllowed1(String userId) {
		TypedQuery<String> query = manager.createQuery("select distinct a.profileDatabasePk.databaseName from ProfileDatabase a, "+
				" UserProfile b where a.profileDatabasePk.profileName = b.userProfilePk.profileName and "+
				" b.userProfilePk.userId=:user ", String.class);
		   query.setParameter("user", userId);
		return query.getResultList();
	}
	
	public List getDatabasesAllowed(String userId) {
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery("select distinct b.database_name \n" + 
				"	from users_profiles a\n" + 
				"	join PROFILES_DATABASES b\n" + 
				"	on a.PROFILE_NAME=b.PROFILE_NAME\n" + 
				"	join profiles c\n" + 
				"	on c.PROFILE_NAME=a.PROFILE_NAME\n" + 
				"	join databases d\n" + 
				"	on d.DATABASE_NAME=b.DATABASE_NAME\n" + 
				"	where\n" + 
				"	c.status='A' and\n" + 
				"	d.status='A' and\n" + 
				"   a.user_id=:user ");
		   query.setParameter("user", userId);
		return query.list();
	} 
	
	public List getDatabasesEnvironmentAllowed(String userId) {
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery("select distinct b.host_name+'-'+b.database_name \n" + 
				"	from users_profiles a\n" + 
				"	join PROFILES_DATABASES b\n" + 
				"	on a.PROFILE_NAME=b.PROFILE_NAME\n" + 
				"	join profiles c\n" + 
				"	on c.PROFILE_NAME=a.PROFILE_NAME\n" + 
				"	join databases d\n" + 
				"	on d.DATABASE_NAME=b.DATABASE_NAME\n" + 
				"	join environments_hostnames e\n" + 
				"	on e.hostname=d.host_name\n" + 
				"	where\n" + 
				"	c.status='A' and\n" + 
				"	d.status='A' and\n" + 
				"   a.user_id=:user and \n" +
				"   e.environment=:env order by 1");
		   query.setParameter("user", userId);
		   query.setParameter("env", System.getProperty("environment"));
		return query.list();
	} 

	public boolean getDatabaseAllowed(String userId, String database) {
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery("select distinct b.database_name \n" + 
				"	from users_profiles a\n" + 
				"	join PROFILES_DATABASES b\n" + 
				"	on a.PROFILE_NAME=b.PROFILE_NAME\n" + 
				"	join profiles c\n" + 
				"	on c.PROFILE_NAME=a.PROFILE_NAME\n" + 
				"	join databases d\n" + 
				"	on d.DATABASE_NAME=b.DATABASE_NAME\n" + 
				"	where\n" + 
				"	c.status='A' and\n" + 
				"	d.status='A' and\n" + 
				"   a.user_id=:user and\n" +
				"   b.database_name=:db");
		   query.setParameter("user", userId);
		   query.setParameter("db", database);
		if ( query.list().isEmpty() ) {
			return false;
		} else {
			return true;
		}
	} 
	
	public boolean getDatabaseEnvironmentAllowed(String userId, String database) {
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery("select distinct b.database_name+'-'+b.host_name \n" + 
				"	from users_profiles a\n" + 
				"	join PROFILES_DATABASES b\n" + 
				"	on a.PROFILE_NAME=b.PROFILE_NAME\n" + 
				"	join profiles c\n" + 
				"	on c.PROFILE_NAME=a.PROFILE_NAME\n" + 
				"	join databases d\n" + 
				"	on d.DATABASE_NAME=b.DATABASE_NAME\n" + 
				"	join environments_hostnames e\n" + 
				"	on e.hostname=d.host_name\n" + 
				"	where\n" + 
				"	c.status='A' and\n" + 
				"	d.status='A' and\n" + 
				"   a.user_id=:user and\n" +
				"   b.database_name=:db and \n"+
				"   e.environment=:env order by b.host_name");
		   query.setParameter("user", userId);
		   query.setParameter("db", database);
		   query.setParameter("env", System.getProperty("environment"));
		if ( query.list().isEmpty() ) {
			return false;
		} else {
			return true;
		}
	} 

	@SuppressWarnings("unchecked")
	public ProfileLimits getLimits(String userId) {
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery("	select " + 
				"	max(connection_timeout) timeperquery, max(number_of_records_per_query) recordsperquery " + 
				"	from PROFILES a " + 
				"	inner join profiles_databases b" + 
				"	on a.profile_name=b.profile_name" + 
				"	inner join users_profiles c" + 
				"	on a.profile_name=c.profile_name" + 
				"	inner join databases d " +
				"	on b.database_name=d.database_name " +
				"	where " +
				"	a.status='A' and" + 
				"	d.status='A' and" + 
				"   c.user_id=:user ");
		   query.setParameter("user", userId);
		   List<Object[]> rows=query.list();
		   for(Object[] row : rows){
			   return new ProfileLimits(Integer.valueOf(row[0].toString()),Integer.valueOf(row[1].toString()));
		   }
		   
		return null;
		
	} 

	@SuppressWarnings("unchecked")
	public boolean udpdateStatus(String userId, String databaseName) {
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery("	select  \n" + 
				"distinct a.INQUIRY_UPDATE\n" + 
				" 				 	from PROFILES a \n" + 
				"				 	inner join profiles_databases b \n" + 
				"				 	on a.profile_name=b.profile_name \n" + 
				"				 	inner join users_profiles c \n" + 
				"				 	on a.profile_name=c.profile_name \n" + 
				"				 	inner join databases d  \n" + 
				"				 	on b.database_name=d.database_name  \n" + 
				"				 	where  \n" + 
				"				 	a.status='A' and \n" + 
				"				 	d.status='A' and \n" + 
				"					d.database_name=:dbname and\n" + 
				"					a.INQUIRY_UPDATE='U' and\n" + 
				"				    c.user_id=:user");
		   query.setParameter("user", userId);
		   query.setParameter("dbname", databaseName);
		   List<String> ret= query.list();
		   if ( ret.size() == 0 ) {
			   return false;
		   } else {
			   return true;
		   }	   
	} 

	@SuppressWarnings("unchecked")
	public List<UserAccess> getAccess(String userId) {
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery(
				"SELECT A.PROFILE_NAME, c.DESCRIPTION, A.host_name, A.DATABASE_NAME, A.UPDATE_ALLOWED, c.NUMBER_OF_RECORDS_PER_QUERY, c.INQUIRY_UPDATE " + 
				"FROM " + 
				"PROFILES_DATABASES A " + 
				"JOIN " + 
				"USERS_PROFILES B " + 
				"ON A.PROFILE_NAME=B.PROFILE_NAME " +
				"JOIN " + 
				"PROFILES C " + 
				"on c.profile_name=a.profile_name " + 
				"WHERE " + 
				"B.USER_ID=:user " + 
				"AND A.STATUS='A' " + 
				"AND B.STATUS='A' " + 
				"ORDER BY host_name, DATABASE_NAME");
		   query.setParameter("user", userId);
		   return query.list();
	} 

	
	public void insert(User user) throws Exception {
		this.manager.persist(user);
	}
	
	public User update(User user) throws Exception  {
		return this.manager.merge(user);
	}
	
	public void delete(User user) throws Exception  {
		this.manager.remove(this.manager.contains(user) ? user : this.manager.merge(user));
//		this.manager.remove(user);
	}

	public EntityManager getManager() {
		return manager;
	}

	public void setManager(EntityManager manager) {
		this.manager = manager;
	}

	public void rollback() {
		if ( manager.getTransaction().isActive() ) {
			manager.getTransaction().rollback();
		}
	}
	
}