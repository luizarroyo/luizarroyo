package com.ing.sql.model;

import java.io.Serializable;

public class IndexDetails implements Serializable {

	private String indexName;
	private int strNumber;
	private String description;
	private String setSubset;
	private String strType;
	private String duplicates;
	private String keychangedok;
	private String condition;

	public IndexDetails(String indexName, 
			            int strNumber,
			            String description,
			            String setSubset,
			            String strType,
			            String duplicates,
			            String keychangedok,
			            String condition) {
		this.condition=condition;
		this.indexName=indexName;
		this.strNumber=strNumber;
		this.strType=strType;
		this.description=description;
		this.duplicates=duplicates;
		this.keychangedok=keychangedok;
		this.setSubset=setSubset;
	}
	
	public String getIndexName() {
		return indexName;
	}
	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}
	public String getStrType() {
		return strType;
	}
	public void setStrType(String strType) {
		this.strType = strType;
	}
	public int getStrNumber() {
		return strNumber;
	}
	public void setStrNumber(int strNumber) {
		this.strNumber = strNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSetSubset() {
		return setSubset;
	}
	public void setSetSubset(String setSubset) {
		this.setSubset = setSubset;
	}
	public String getDuplicates() {
		return duplicates;
	}
	public void setDuplicates(String duplicates) {
		this.duplicates = duplicates;
	}
	public String getKeychangedok() {
		return keychangedok;
	}
	public void setKeychangedok(String keychangedok) {
		this.keychangedok = keychangedok;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	
	
	
}
