package com.ing.sql.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.transaction.Transactional;
import javax.validation.constraints.Size;

import org.hibernate.annotations.ColumnDefault;

@Entity
@org.hibernate.annotations.Check(constraints = "(userId NOT = '')")
@Table(name = "USERS")
@Transactional
public class User implements Serializable {

	private static final long serialVersionUusercode = 1L;
	
	@Size(max=6)
	private String userId;
	private int matricule;
	private String name;
	private int typeSupport;
	private int typeAdmin;
	private int typeBasic;
	private int typeOperator;
	private int typeSuperUser;
	private String email;
	private int numberOfRecordsPerQuery;
	private String inquiryUpdate;
	private int connectionTimeout;
	private Timestamp lastAccessDate;
	private String lastAccessIp;
	private Timestamp lastUpdateDate;
	private String status;
	private String who;
	
	private String password;
	
	public User() {
		typeBasic=1;
		numberOfRecordsPerQuery=1000;
		connectionTimeout=900;
		inquiryUpdate="I";
		status="A";
	}
	
	@Id
	@Size(max = 6)
	@Column(name = "USER_ID",length = 6, nullable = false)
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(name = "MATRICULE",nullable = false)
	public int getMatricule() {
		return matricule;
	}

	public void setMatricule(int matricule) {
		this.matricule = matricule;
	}

	
	
	@Column(name = "NAME",length = 40, nullable = false)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "TYPE_SUPPORT")
	@ColumnDefault("N")
	public boolean getTypeSupport() {
		if ( typeSupport == 1 )
			return true;
		else
			return false;
	}

	public void setTypeSupport(boolean support) {
		if ( support ) {
			this.typeSupport = 1;
		} else {
			this.typeSupport = 0;			
		}
	}

	@Column(name = "TYPE_ADMIN")
	@ColumnDefault("N")
	public boolean getTypeAdmin() {
		if ( typeAdmin == 1 )
			return true;
		else
			return false;
	}

	public void setTypeAdmin(boolean admin) {
		if ( admin ) {
			this.typeAdmin = 1;
		} else {
			this.typeAdmin = 0;			
		}
	}

	@Column(name = "TYPE_BASIC")
	@ColumnDefault("N")
	public boolean getTypeBasic() {
		if ( typeBasic == 1 )
			return true;
		else
			return false;
	}

	public void setTypeBasic(boolean basic) {
		if ( basic ) {
			this.typeBasic = 1;
		} else {
			this.typeBasic = 0;			
		}
	}

	@Column(name = "TYPE_OPERATOR")
	@ColumnDefault("N")
	public boolean getTypeOperator() {
		if ( typeOperator == 1 )
			return true;
		else
			return false;
	}

	public void setTypeOperator(boolean operator) {
		if ( operator ) {
			this.typeOperator = 1;
		} else {
			this.typeOperator = 0;			
		}
	}

	@Column(name = "TYPE_SUPERUSER")
	@ColumnDefault("N")
	public boolean getTypeSuperUser() {
		if ( typeSuperUser == 1)
			return true;
		else
			return false;
	}

	public void setTypeSuperUser(boolean superUser) {
		if ( superUser ) {
			this.typeSuperUser = 1;
		} else {
			this.typeSuperUser = 0;			
		}
	}

	@Column(name = "EMAIL",length = 40)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "NUMBER_OF_RECORDS_PER_QUERY")
	@ColumnDefault("1000")
	public int getNumberOfRecordsPerQuery() {
		return numberOfRecordsPerQuery;
	}

	public void setNumberOfRecordsPerQuery(int numberOfRecordsPerQuery) {
		this.numberOfRecordsPerQuery = numberOfRecordsPerQuery;
	}

	@Column(name = "INQUIRY_UPDATE",length = 1, nullable = false)
	@ColumnDefault("I")
	public String getInquiryUpdate() {
		return inquiryUpdate;
	}

	public void setInquiryUpdate(String inquiryUpdate) {
		this.inquiryUpdate = inquiryUpdate;
	}

	@Column(name = "CONNECTION_TIMEOUT")
	@ColumnDefault("900")
	public int getConnectionTimeout() {
		return connectionTimeout;
	}

	public void setConnectionTimeout(int connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	@Column(name = "LAST_ACCESS_DATE", nullable = true)
	public Timestamp getLastAccessDate() {
		return lastAccessDate;
	}

	public void setLastAccessDate(Timestamp lastAccessDate) {
		this.lastAccessDate = lastAccessDate;
	}

	@Column(name = "LAST_ACCESS_IP",length = 15, nullable = true)
	public String getLastAccessIp() {
		return lastAccessIp;
	}

	public void setLastAccessIp(String lastAccessIp) {
		this.lastAccessIp = lastAccessIp;
	}

	@Column(name = "UPDATED_DATE", insertable=false)
	public Timestamp getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Timestamp lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	@Column(name = "STATUS",length = 1)
	@ColumnDefault("A")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "WHO",length = 6, nullable = false)
	public String getWho() {
		return who;
	}

	public void setWho(String who) {
		this.who = who;
	}

	
	public String getPassword() {
		return password;
	}

	
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!(userId == other.userId))
			return false;
		return true;
	}

	public String inqUpd(String value) {
		if (value.equals("U") ) {
			return "Update";
		} else {
			return "Inquiry";
		}
	}

	public String type(boolean value) {
		if (value  == false ) {
			return "No";
		} else {
			return "Yes";
		}
	}

	public String status(String value) {
		if (value.equals("A") ) {
			return "Active";
		} else {
			return "Suspended";
		}
	}

}