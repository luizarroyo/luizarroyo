package com.ing.sql.util;

import java.io.Serializable;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

@ApplicationScoped
@ManagedBean
public class ThemeBean implements Serializable {

    public String getApplicationTheme() {
        return "ui-lightness";
    }
    
}
