package com.ing.sql.model;

import java.io.Serializable;

public class IndexFieldsDetails implements Serializable {

	private String indexName;
	private String dataname;
	private String description;
	private int fieldSequence;
	private String descAsc;
	private String datatype;
	private int length;
	private int decimals;

	public IndexFieldsDetails(String indexName, 
						String dataname,
						String description,
			            int fieldSequence,
			            String descAsc,
			            String datatype,
			            int length,
			            int decimals) {
		this.dataname=dataname;
		this.indexName=indexName;
		this.fieldSequence=fieldSequence;
		this.descAsc=descAsc;
		this.description=description;
		this.datatype=datatype;
		this.length=length;
		this.decimals=decimals;
	}

	public String getIndexName() {
		return indexName;
	}

	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}

	public String getDataname() {
		return dataname;
	}

	public void setDataname(String dataname) {
		this.dataname = dataname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getFieldSequence() {
		return fieldSequence;
	}

	public void setFieldSequence(int fieldSequence) {
		this.fieldSequence = fieldSequence;
	}

	public String getDescAsc() {
		return descAsc;
	}

	public void setDescAsc(String descAsc) {
		this.descAsc = descAsc;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getDecimals() {
		return decimals;
	}

	public void setDecimals(int decimails) {
		this.decimals = decimails;
	}
	
	
}
