package com.ing.sql.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Enumeration;

/** 
 * Copyright (C) 2009 "Darwin V. Felix" <darwinfelix@users.sourceforge.net>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LdapCheckUserGroup {

    public static void main(String[] args) throws Exception {
    	
    	new LdapCheckUserGroup().checkUserGroup("TD15NM");

    }
       
    public int checkUserGroup(String corporateKey ) throws Exception {

	    String dc = "DC=ad,DC=ing,DC=net";
		String dn = "cn=TD15NMd,CN=Users," + dc;
	    String username = "TD15NM";
	    String domain="AD";
	    String password="Granja77Vianna";
		int returnValue=0;
		
	    Hashtable<String, String> env = new Hashtable<String, String>();
	    env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
	    env.put(Context.SECURITY_AUTHENTICATION, "simple");
	    env.put("com.sun.jndi.ldap.connect.pool", "true");
	    env.put(Context.SECURITY_PROTOCOL, "ssl");
	    env.put(Context.SECURITY_PRINCIPAL, domain+"\\"+username);
	    env.put(Context.SECURITY_CREDENTIALS, password);
	    env.put(Context.PROVIDER_URL, "ldaps://sa1000000020.ad.ing.net:636"); //636
	
	    DirContext context = new InitialDirContext(env);
	    
	    final String filter = String.format("(&(sAMAccountType=805306368)(sAMAccountName=%1$s))", corporateKey);
	            
	    SearchControls constraints = new SearchControls();
	    constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
	
	    String[] attrIDs = {  "memberOf" };
	    constraints.setReturningAttributes(attrIDs);
	
	    NamingEnumeration<?> answer = context.search("DC=ad,DC=ing,DC=net","sAMAccountName=" + username, constraints);
	    if (answer.hasMore()) {
	
	    	Attributes memberOf = ((SearchResult) answer.next()).getAttributes();
	        if (memberOf != null) {
	            for ( Enumeration e1 = memberOf.getAll() ; e1.hasMoreElements() ; ) {
	                String [] pieces=e1.nextElement().toString().split(",");
	                for (int i=0; i<pieces.length; i++) {
	                	if ( pieces[i].indexOf("CN=") > 0 ) {
	                		System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": Group="+pieces[i].substring(pieces[i].indexOf("CN=")+3));
	                		returnValue=1;
	                	}
	                }
	            }    
	        }
	
		} else {
			System.out.println(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime())+": Invalid User:"+corporateKey);
		}
	
	    return returnValue;
	    
    }

}