package com.ing.sql.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.ing.sql.model.IndexDataname;
import com.ing.sql.model.IndexDetails;
import com.ing.sql.model.IndexFieldsDetails;

public class Indexes implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public Indexes(EntityManager manager) {
		this.manager = manager;
	}

	public List<IndexDetails> allIndexes(String database, String dataset) {
		
		List<IndexDetails> id = new ArrayList<IndexDetails>();
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery("	select " + 
				"Indexes.index_name, Indexes.str_number,Indexes.description, Indexes.set_subset, Indexes.str_type, Indexes.duplicates, Indexes.keychangedok, " + 
				"IndexWhere.condition  " + 
				"from  " + 
				"Datasets Dataset " + 
				"join Indexes  " + 
				"on Dataset.database_name=Indexes.database_name and " + 
				"   Dataset.dataset_name=Indexes.dataset_name " + 
				"left join Indexes_Where IndexWhere " + 
				"on IndexWhere.database_name=Indexes.database_name and " + 
				"   IndexWhere.dataset_name=Indexes.dataset_name and " + 
				"   IndexWhere.index_name=Indexes.index_name " + 
				"where  " + 
				"Dataset.database_name=:database and " + 
				"Dataset.dataset_name=:dataset");
		query.setParameter("database", database);
		query.setParameter("dataset", dataset);
 	    List<Object[]> rows=query.list();
	    for(Object[] row : rows){
	    	if ( row[7] == null ) {
	    		id.add(new IndexDetails(row[0].toString(),Integer.valueOf(row[1].toString()),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),""));
	    	} else {
	    		id.add(new IndexDetails(row[0].toString(),Integer.valueOf(row[1].toString()),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),row[7].toString()));
	    	}
		}
	    return id;
	}


	public List<IndexFieldsDetails> allFields(String database, String dataset, String index) {
		
		List<IndexFieldsDetails> id = new ArrayList<IndexFieldsDetails>();
		Session session = manager.unwrap(Session.class);
		SQLQuery query = session.createSQLQuery("	select " + 
				"	id.index_name, " + 
				"	id.dataname, dn.description, id.field_sequence, id.asc_desc, " + 
				"	dn.datatype, dn.length, dn.decimals " +
				"	from  " +
				"	datasets ds " +
				"	join indexes ix  " +
				"	on ds.database_name=ix.database_name and " +
				"	   ds.dataset_name=ix.dataset_name " +
				"	join indexes_datanames id " +
				"	on id.database_name=ix.database_name and " +
				"	   id.dataset_name=ix.dataset_name and " +
				"	   id.index_name=ix.index_name " +
				"	join datanames dn " +
				"	on dn.database_name=id.database_name and " +
				"	   dn.dataset_name=id.dataset_name and  " +
				"	   dn.dataname=id.dataname " +
				"	where  " +
				"	ds.database_name=:database and " +
				"	ds.dataset_name=:dataset and " +
				"	ix.index_name=:index " +
				"	order by ix.index_name, id.field_sequence");
		query.setParameter("database", database);
		query.setParameter("dataset", dataset);
		query.setParameter("index", index);
 	    List<Object[]> rows=query.list();
	    for(Object[] row : rows){
    		id.add(new IndexFieldsDetails(row[0].toString(),row[1].toString(),row[2].toString(),Integer.valueOf(row[3].toString()),row[4].toString(),row[5].toString(),Integer.valueOf(row[6].toString()),Integer.valueOf(row[7].toString())));
		}
	    return id;
	}
	
	public List<IndexDataname> indexNoDuplicates(String database, String dataset) {
		TypedQuery<IndexDataname> query = manager.createQuery("from IndexDataname WHERE  " + 
				" databaseName=:db AND datasetName=:ds " + 
				" and indexName IN (SELECT indexName  FROM Index WHERE " + 
				" databaseName=:db AND datasetName=:ds AND " + 
				" duplicates='NO DUPLICATES') ORDER BY indexName, fieldSequence", IndexDataname.class);
		query.setParameter("db", database);
		query.setParameter("ds", dataset);
		return query.getResultList();
	}

}
