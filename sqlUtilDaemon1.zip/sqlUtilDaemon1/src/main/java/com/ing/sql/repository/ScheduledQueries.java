package com.ing.sql.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.ing.sql.model.ScheduleQuery;

public class ScheduledQueries implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public ScheduledQueries(EntityManager manager) {
		this.manager = manager;
	}

	 public ScheduleQuery byScheduleId(int id) { return
	  manager.find(ScheduleQuery.class, id); }
	 
	
	public List<ScheduleQuery> allByUser(String userId, String filter) {
		TypedQuery<ScheduleQuery> query = manager.createQuery(
			"from ScheduleQuery where (USER_ID = :userId) and sql_statement like :filter order by USER_ID, SCHEDULE_NAME"
				, ScheduleQuery.class);
		System.out.println("******Query*****"+query);
		query.setParameter("userId", userId);
		query.setParameter("filter", "%"+filter.trim()+"%");
		return query.getResultList();
	}

	public List<ScheduleQuery> all(String filter) {
		TypedQuery<ScheduleQuery> query = manager.createQuery(
			"from ScheduleQuery where sql_statement like :filter or :filter='' order by USER_ID, SCHEDULE_NAME"
				, ScheduleQuery.class);
		System.out.println("******Query*****"+query);
		query.setParameter("filter", filter.trim());
		return query.getResultList();
	}


	public void insert(ScheduleQuery scheduleQuery) {
		this.manager.persist(scheduleQuery);
	}
	
	public ScheduleQuery update(ScheduleQuery scheduleQuery) {
		return this.manager.merge(scheduleQuery);
	}
	
	public void delete(ScheduleQuery scheduleQuery) {
		this.manager.remove(scheduleQuery);
	}

	public void flush() {
		manager.flush();
	}
	
	public void rollback() {
		if ( manager.getTransaction().isActive() ) {
			manager.getTransaction().rollback();
		}
	}
	
}
