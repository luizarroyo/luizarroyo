package com.ing.sql.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "SCHEDULE_QUERIES")
//@IdClass(ScheduleQueryPk.class)
public class ScheduleQuery implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@Column(name = "ID", insertable = false)
    protected int scheduleId;
	@Column(name = "SCHEDULE_NAME",length = 50, nullable = true)
    protected String scheduleName;
    @Column(name = "USER_ID",length = 6, nullable = false)
    protected String userId;
	@Column(name = "DATABASE_NAME",length = 17, nullable = true)
	private String databaseName;
	
    @Column(name = "LAST_ID",length = 1, nullable = false)
    protected int lastId;
	
	@Column(name = "HOST_NAME",length = 7, nullable = true)
	private String hostName;
	@Column(name = "LAST_REQUEST_DATE")
	private Date lastRequestedDate;

	@Column(name = "SQL_STATEMENT",length = 2000, nullable = false)
	private String sqlStatement;
   // [run_mon] char(1),
    @Column(name = "run_mon",length = 1, nullable = true)
    protected String run_mon;
   // [run_tue] char(1),
    @Column(name = "run_tue",length = 1, nullable = true)
    protected String run_tue;
    // [run_wed] char(1),
    @Column(name = "run_wed",length = 1, nullable = true)
    protected String run_wed;
    //[run_thu] char(1),
    @Column(name = "run_thu",length = 1, nullable = true)
    protected String run_thu;
    //[run_fri] char(1),
    @Column(name = "run_fri",length = 1, nullable = true)
    protected String run_fri;
    //[run_sat] char(1),
    @Column(name = "run_sat",length = 1, nullable = true)
    protected String run_sat;
    // [run_sun] char(1),
    @Column(name = "run_sun",length = 1, nullable = true)
    protected String run_sun;
    //[run_daily] char(1),
    @Column(name = "run_daily",length = 1, nullable = true)
    protected String run_daily;
    
    //[run_in_day_of_the_month] smallint,
    @Column(name = "run_in_day_of_the_month",length = 2, nullable = true)
    protected int runInDayOfMonth;
    // [REQUESTED_DATE] [datetime2] (7) NULL,
    @Column(name = "REQUESTED_DATE")
   	private Date requestedDate;
    // [REQUESTED_TIME] [datetime2] (7) NULL,
    @Column(name = "REQUESTED_TIME")
   	private Date requestedTime; 
    //[REPEAT_AFTER] [int] NULL,
    @Column(name = "REPEAT_AFTER",length = 7, nullable = true)
    protected int repeatAfter;
    //[STATUS] [char](1) NULL,
    @Column(name = "STATUS", length = 1, nullable = true)
	@ColumnDefault("A")
	private String status;
    //  [CREATED_DATE] [datetime2](7) NULL,
    @Column(name = "CREATED_DATE")
	private Date createdDate;
   
	public int getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}
	public int getLastId() {
		return lastId;
	}
	public void setLastId(int lastId) {
		this.lastId = lastId;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public Date getLastRequestedDate() {
		return lastRequestedDate;
	}
	public void setLastRequestedDate(Date lastRequestedDate) {
		this.lastRequestedDate = lastRequestedDate;
	}
	public String getRun_mon() {
		return run_mon;
	}
	public void setRun_mon(String run_mon) {
		this.run_mon = run_mon;
	}
	public String getRun_tue() {
		return run_tue;
	}
	public void setRun_tue(String run_tue) {
		this.run_tue = run_tue;
	}
	public String getRun_wed() {
		return run_wed;
	}
	public void setRun_wed(String run_wed) {
		this.run_wed = run_wed;
	}
	public String getRun_thu() {
		return run_thu;
	}
	public void setRun_thu(String run_thu) {
		this.run_thu = run_thu;
	}
	public String getRun_fri() {
		return run_fri;
	}
	public void setRun_fri(String run_fri) {
		this.run_fri = run_fri;
	}
	public String getRun_sat() {
		return run_sat;
	}
	public void setRun_sat(String run_sat) {
		this.run_sat = run_sat;
	}
	public String getRun_sun() {
		return run_sun;
	}
	public void setRun_sun(String run_sun) {
		this.run_sun = run_sun;
	}
	public String getRun_daily() {
		return run_daily;
	}
	public void setRun_daily(String run_daily) {
		this.run_daily = run_daily;
	}
	public int getRunInDayOfMonth() {
		return runInDayOfMonth;
	}
	public void setRunInDayOfMonth(int runInDayOfMonth) {
		this.runInDayOfMonth = runInDayOfMonth;
	}
	public Date getRequestedDate() {
		return requestedDate;
	}
	public void setRequestedDate(Date requestedDate) {
		this.requestedDate = requestedDate;
	}
	public Date getRequestedTime() {
		return requestedTime;
	}
	public void setRequestedTime(Date requestedTime) {
		this.requestedTime = requestedTime;
	}
	public int getRepeatAfter() {
		return repeatAfter;
	}
	public void setRepeatAfter(int repeatAfter) {
		this.repeatAfter = repeatAfter;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getScheduleName() {
		return scheduleName;
	}
	public void setScheduleName(String scheduleName) {
		this.scheduleName = scheduleName;
	}
	
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public String getSqlStatement() {
		return sqlStatement;
	}
	public void setSqlStatement(String sqlStatement) {
		this.sqlStatement = sqlStatement;
	}
	
		
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public String status(String status) {
		if (status.equals("A") ) {
			return "Active";
		}  else if (status.equals("S") ) {
			return "Suspended";
	}else {
			return "Deleted";
		}
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((scheduleName == null) ? 0 : scheduleName.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ScheduleQuery other = (ScheduleQuery) obj;
		if (scheduleName == null) {
			if (other.scheduleName != null)
				return false;
		} else if (!scheduleName.equals(other.scheduleName))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}


}
