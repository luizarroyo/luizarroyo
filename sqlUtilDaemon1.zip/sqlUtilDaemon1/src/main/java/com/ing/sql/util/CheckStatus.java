package com.ing.sql.util;

import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

@Named
@ViewScoped
public class CheckStatus implements Serializable {

public void checkUser() throws Exception {
	
    if ( getUser() == null ) {
    	FacesContext.getCurrentInstance().getExternalContext().redirect("Login.xhtml");
    	return;
    }

}

public String getUser() {
	FacesContext context = FacesContext.getCurrentInstance();
	return (String)context.getExternalContext().getSessionMap().get("user");
}

}
