package com.ing.sql.model;

import java.io.Serializable;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "USERS_SQL_ACTIVITIES")
public class UserSqlHistory implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@Column(name = "ID", nullable = false)
	private int Id;
	@Column(name = "USER_ID",length = 6, nullable = false)
	private String userId;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)	
	@Column(name = "ACTIVITY_DATE", nullable = false)
	private Date historyDate;
	@Column(name = "DATABASE_NAME",length = 17, nullable = false)
	private String databaseName;
	@Column(name = "HOST_NAME",length = 17, nullable = false)
	private String hostName;
	@Column(name = "SQL_STATEMENT",length = 2000, nullable = false)
	private String sqlStatement;
	@Column(name = "EXECUTION_TIME", nullable = false)
	private float executionTime;
	@Column(name = "NUMBER_OF_RETURNED_RECORDS", nullable = false)
	private int numberOfReturnedRecords;
	@Column(name = "MESSAGE",length = 100)
	private String message;
	@Column(name = "REASON",length = 500)
	private String reason;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public Date getHistoryDate() {
		return historyDate;
	}
	public void setHistoryDate(Date historyDate) {
		this.historyDate = historyDate;
	}
	
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public String getSqlStatement() {
		return sqlStatement;
	}
	public void setSqlStatement(String sqlStatement) {
		if ( sqlStatement.length() > 4000 ) {
			this.sqlStatement = sqlStatement.substring(0,4000);
		} else {
			this.sqlStatement = sqlStatement;
		}
	}
	
	public double getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(float executionTime) {
		this.executionTime = executionTime;
	}
	
	public int getNumberOfReturnedRecords() {
		return numberOfReturnedRecords;
	}
	public void setNumberOfReturnedRecords(int numberOfReturnedRecords) {
		this.numberOfReturnedRecords = numberOfReturnedRecords;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	


}
