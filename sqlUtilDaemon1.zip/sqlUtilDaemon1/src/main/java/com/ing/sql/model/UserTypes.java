package com.ing.sql.model;

public enum UserTypes {

	ADMIN("Admin"), 
	NORMAL("Normal");

	private String description;
	
	UserTypes(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

}