package com.ing.sql.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "users_profiles")
public class UserProfile implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
    private UserProfilePk userProfilePk;
	@Column(name = "UPDATE_ALLOWED",length = 1, nullable = true)
	@ColumnDefault("N")
	private String updateAllowed;
	@Column(name = "UPDATED_DATE", insertable=false)
	private Date updatedDate;
	@Column(name = "STATUS", length = 1, nullable = false, insertable=false)
	@ColumnDefault("A")
	private String status;
	@Column(name = "WHO", length = 6, nullable = false)
	private String who;
	
	public UserProfilePk usersProfilesPk() {
		return userProfilePk;
	}

	public void setUsersProfilesPK(UserProfilePk userProfilePk) {
		this.userProfilePk = userProfilePk;
	}

	public UserProfilePk getUsersProfilesPK() {
		return this.userProfilePk;
	}

	public String getUpdateAllowed() {
		return updateAllowed;
	}

	public void setUpdateAllowed(String updateAllowed) {
		this.updateAllowed = updateAllowed;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getWho() {
		return who;
	}

	public void setWho(String who) {
		this.who = who;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userProfilePk == null) ? 0 : userProfilePk.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserProfile other = (UserProfile) obj;
		if (userProfilePk == null) {
			if (other.userProfilePk != null)
				return false;
		} else if (!userProfilePk.equals(other.userProfilePk))
			return false;
		return true;
	}


	
}

