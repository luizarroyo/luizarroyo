package com.ing.sql.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "SQL_STATEMENTS")
@IdClass(SqlStatementPk.class)
public class SqlStatement implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
    @Column(name = "USER_ID",length = 6, nullable = false)
    protected String userId;
	@Id
    @Column(name = "QUERY_NAME",length = 50, nullable = false)
    protected String queryName;
	@Id
	@Column(name = "DATABASE_NAME",length = 17, nullable = true)
	private String databaseName;

	@Column(name = "SQL_STATEMENT",length = 2000, nullable = false)
	private String sqlStatement;
	@Column(name = "DESCRIPTION",length = 500)
	private String description;
	@Column(name = "UPDATED_DATE")
	private Date updatedDate;
	@Column(name = "SECURITY")
	@ColumnDefault("R")
	private String security;
	@Column(name = "STATUS", length = 1, nullable = false)
	@ColumnDefault("A")
	private String status;
	@Column(name = "WHO", length = 6, nullable = false)
	private String who;
	

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getQueryName() {
		return queryName;
	}
	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}
	
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public String getSqlStatement() {
		return sqlStatement;
	}
	public void setSqlStatement(String sqlStatement) {
		this.sqlStatement = sqlStatement;
	}
	
	public String getSecurity() {
		return security;
	}
	public void setSecurity(String security) {
		this.security = security;
	}
	
	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getWho() {
		return who;
	}

	public void setWho(String who) {
		this.who = who;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String security(String security) {
		if (security.equals("R") ) {
			return "Restrict";
		} else {
			return "Public";
		}
	}

	public String status(String status) {
		if (status.equals("A") ) {
			return "Active";
		} else {
			return "Suspended";
		}
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((queryName == null) ? 0 : queryName.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SqlStatement other = (SqlStatement) obj;
		if (queryName == null) {
			if (other.queryName != null)
				return false;
		} else if (!queryName.equals(other.queryName))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}


}
