package com.ing.sql.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.ing.sql.model.ProfileDatabase;
import com.ing.sql.model.ProfileDatabasePk;


public class ProfilesDatabases implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private EntityManager manager;

	@Inject
	public ProfilesDatabases(EntityManager manager) {
		this.manager = manager;
	}

	public ProfileDatabase byId(ProfileDatabasePk id) {
		return manager.find(ProfileDatabase.class, id);
	}
	
	public List<String> test(String desc) {
		TypedQuery<String> query = manager.createQuery(
				"select   "
				+ "where upper(desc) like upper(:desc)", 
				String.class);
		query.setParameter("desc", "%" + desc + "%");
		return query.getResultList();
	}
	
	public List<ProfileDatabase> all() {
		TypedQuery<ProfileDatabase> query = manager.createQuery(
				"from ProfileDatabase order by profileDatabasePk.profileName, profileDatabasePk.databaseName", ProfileDatabase.class);
		return query.getResultList();
	}

	public List<String> profiles(String databaseName, String hostName) {
		TypedQuery<String> query = manager.createQuery(
				"select up.profileDatabasePk.profileName from ProfileDatabase up where up.profileDatabasePk.databaseName = :databaseName and up.profileDatabasePk.hostName = :hostName order by up.profileDatabasePk.profileName", String.class);
		query.setParameter("databaseName", databaseName );
		query.setParameter("hostName", hostName );
		return query.getResultList();
	}

	public List<String> notProfiles(String databaseName, String hostName) {
		TypedQuery<String> query = manager.createQuery(
		               "select database0_.profileName from Profile database0_ " + 
		               "where " + 
		               "not exists (select 1 from ProfileDatabase profiledat1_ where " + 
		               "profiledat1_.profileDatabasePk.profileName=database0_.profileName and " + 
		               "profiledat1_.profileDatabasePk.databaseName=:databaseName and " + 
		               "profiledat1_.profileDatabasePk.hostName=:hostName " + 
		               ") " + 
		               "order by database0_.profileName", String.class);
		query.setParameter("databaseName", databaseName );
		query.setParameter("hostName", hostName );
		return query.getResultList();
	}

	public List<String> databases(String profileName) {
		TypedQuery<String> query = manager.createQuery(
				"select up.profileDatabasePk.databaseName+' '+up.profileDatabasePk.hostName from ProfileDatabase up where up.profileDatabasePk.profileName = :profileName order by up.profileDatabasePk.databaseName, up.profileDatabasePk.hostName", String.class);
		query.setParameter("profileName", profileName );
		return query.getResultList();
	}

	public List<String> notDatabases(String profileName) {
		TypedQuery<String> query = manager.createQuery(
		               "select database0_.databaseName+' '+database0_.hostName as col_0_0_ from Database database0_ " + 
		               "where " + 
		               "not exists (select 1 from ProfileDatabase profiledat1_ where " + 
		               "profiledat1_.profileDatabasePk.profileName=:profileName and " + 
		               "profiledat1_.profileDatabasePk.databaseName=database0_.databaseName and " + 
		               "profiledat1_.profileDatabasePk.hostName=database0_.hostName " + 
		               ") " + 
		               "order by database0_.databaseName, database0_.hostName", String.class);
		query.setParameter("profileName", profileName );
		return query.getResultList();
	}

	public List<ProfileDatabase> databasesPerProfile(String profileName) {
		TypedQuery<ProfileDatabase> query = manager.createQuery(
				"from ProfileDatabase up where up.profileDatabasePk.profileName = :profileName order by up.profileDatabasePk.databaseName, up.profileDatabasePk.hostName", ProfileDatabase.class);
		query.setParameter("profileName", profileName );
		return query.getResultList();
	}

	public void insert(ProfileDatabase ProfileDatabase) {
		this.manager.persist(ProfileDatabase);
	}
	
	public ProfileDatabase update(ProfileDatabase ProfileDatabase) {
		return this.manager.merge(ProfileDatabase);
	}
	
	public void delete(ProfileDatabase ProfileDatabase) {
		this.manager.remove(ProfileDatabase);
	}

	
	public void rollback() {
		if ( manager.getTransaction().isActive() ) {
			manager.getTransaction().rollback();
		}
	}
	

}