package com.ing.sql.model;

import javax.persistence.Column;

public class ProfileLimits {

	@Column(name = "timeperquery")
	int timeperquery;
	@Column(name = "recordsperquery")
	int recordsperquery;
	
	public ProfileLimits() {
	}

	public ProfileLimits(int timeperquery, int recordsperquwry) {
		this.recordsperquery=recordsperquwry;
		this.timeperquery=timeperquery;			
	}
	
	public int getRecordsperquery() {
		return recordsperquery;
	}
	public void setRecordsperquery(int recordsperquery) {
		this.recordsperquery = recordsperquery;
	}
	public int getTimeperquery() {
		return timeperquery;
	}
	public void setTimeperquery(int timeperquery) {
		this.timeperquery = timeperquery;
	}
	
	
}
