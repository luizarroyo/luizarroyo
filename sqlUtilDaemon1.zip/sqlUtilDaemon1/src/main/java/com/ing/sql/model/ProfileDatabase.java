package com.ing.sql.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "profiles_databases")
public class ProfileDatabase implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
    private ProfileDatabasePk profileDatabasePk;
//	private String tableName;
	@Column(name = "UPDATED_DATE", length = 6, nullable = false)
	private Date updatedDate;
	@Column(name = "STATUS", length = 1, nullable = false)
	@ColumnDefault("A")
	private String status;
	@Column(name = "WHO", length = 6, nullable = false)
	private String who;
	
	public ProfileDatabasePk getProfileDatabasePk() {
		return profileDatabasePk;
	}
	public void setProfileDatabasePk(ProfileDatabasePk profileDatabasePk) {
		this.profileDatabasePk = profileDatabasePk;
	}

//	@Column(name = "TABLE_NAME",length = 30, nullable = false)
//	public String getTableName() {
//		return tableName;
//	}
//	public void setTableName(String tableName) {
//		this.tableName = tableName;
//	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getWho() {
		return who;
	}

	public void setWho(String who) {
		this.who = who;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((profileDatabasePk == null) ? 0 : profileDatabasePk.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProfileDatabase other = (ProfileDatabase) obj;
		if (profileDatabasePk == null) {
			if (other.profileDatabasePk != null)
				return false;
		} else if (!profileDatabasePk.equals(other.profileDatabasePk))
			return false;
		return true;
	}

	
}
