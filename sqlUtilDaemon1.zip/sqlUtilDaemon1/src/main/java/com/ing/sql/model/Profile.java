package com.ing.sql.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PROFILES")
public class Profile implements Serializable {

	private static final long serialVersionUusercode = 1L;
	
	@Id
	@Column(name = "PROFILE_NAME",length = 30, nullable = false)
	private String profileName;
	@Column(name = "DESCRIPTION", nullable = false)
	private String description;
	@Column(name = "NUMBER_OF_RECORDS_PER_QUERY", nullable = false)
	private int numberOfRecordsPerQuery;
	@Column(name = "INQUIRY_UPDATE",length = 1, nullable = false)
	private String inquiryUpdate;
	@Column(name = "CONNECTION_TIMEOUT")
	private int connectionTimeout;
	@Column(name = "UPDATED_DATE")
	private Timestamp updatedDate;
	@Column(name = "STATUS",length = 1)
	private String status;
	@Column(name = "WHO",length = 6)
	private String who;
	
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	
	public int getNumberOfRecordsPerQuery() {
		return numberOfRecordsPerQuery;
	}
	public void setNumberOfRecordsPerQuery(int numberOfRecordsPerQuery) {
		this.numberOfRecordsPerQuery = numberOfRecordsPerQuery;
	}
	
	public String getInquiryUpdate() {
		return inquiryUpdate;
	}
	public void setInquiryUpdate(String inquiryUpdate) {
		this.inquiryUpdate = inquiryUpdate;
	}
	
	public int getConnectionTimeout() {
		return connectionTimeout;
	}
	public void setConnectionTimeout(int connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}
	
	public Timestamp getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getWho() {
		return who;
	}
	public void setWho(String who) {
		this.who = who;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String inqUpd(String value) {
		if (value.equals("U") ) {
			return "Update";
		} else {
			return "Inquiry";
		}
	}

	public String status(String value) {
		if (value.equals("A") ) {
			return "Active";
		} else {
			return "Suspended";
		}
	}
	

}
